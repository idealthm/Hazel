#include "Example.h"
#include "ImGui/imgui.h"

#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Platform/OpenGL/OpenGLShader.h"

ExampleLayer::ExampleLayer()
// ��ʼ��������ݱ� aspect ratio.
	:Layer("Example"), m_Camera(-1.6f, 1.6f, 0.9f, -0.9f), m_ModelPosition(0.0f)
{
	m_VertexArray.reset(Hazel::VertexArray::Create());

	float vertices[3 * 7] = {
		-0.5f, -0.5f, 0.0f, 0.8f, 0.2f, 0.8f , 1.0f,
		 0.5f, -0.5f, 0.0f, 0.2f, 0.2f, 0.8f , 1.0f,
		 0.0f,  0.5f, 0.0f, 0.8f, 0.8f, 0.2f , 1.0f
	};

	m_VertexBuffer.reset(Hazel::VertexBuffer::Create(vertices, sizeof(vertices)));
	Hazel::BufferLayout layout = {
		{Hazel::ShaderDataType::Float3, "a_Position"},
		{Hazel::ShaderDataType::Float4, "a_Color"}
	};

	m_VertexBuffer->SetLayout(layout);

	m_VertexArray->AddVertexBuffer(m_VertexBuffer);

	unsigned int indices[3] = { 0, 1, 2 };
	m_IndexBuffer.reset(Hazel::IndexBuffer::Create(indices, sizeof(indices) / sizeof(uint32_t)));

	m_VertexArray->SetIndexBuffer(m_IndexBuffer);

	// Texture 

	m_TVArray.reset(Hazel::VertexArray::Create());
	float texturevertices[5 * 4] = {
		-0.5f, -0.5f, 0.0f, 0.0f, 0.0f,
		 0.5f, -0.5f, 0.0f, 1.0f, 0.0f,
		 0.5f,  0.5f, 0.0f, 1.0f, 1.0f,
		-0.5f,  0.5f, 0.0f, 0.0f, 1.0f
	};
	Hazel::Ref<Hazel::VertexBuffer> TVB;
	TVB.reset(Hazel::VertexBuffer::Create(texturevertices, sizeof(texturevertices)));
	TVB->SetLayout({
		{ Hazel::ShaderDataType::Float3, "a_Position"},
		{ Hazel::ShaderDataType::Float2, "a_TexCoord"}
		});
	m_TVArray->AddVertexBuffer(TVB);
	uint32_t TIndices[6] = { 0, 1, 2, 2, 3, 0 };
	Hazel::Ref<Hazel::IndexBuffer> TIB;
	TIB.reset(Hazel::IndexBuffer::Create(TIndices, sizeof(TIndices) / sizeof(uint32_t)));
	m_TVArray->SetIndexBuffer(TIB);

	m_Shader.reset(Hazel::Shader::Create("Assets/Shaders/Triangle.glsl"));
	m_TShader.reset(Hazel::Shader::Create("Assets/Shaders/Texture.glsl"));

	m_Texture = Hazel::Texture2D::Create("Assets/Textures/Checkborad.png");
	m_LogoTexture = Hazel::Texture2D::Create("Assets/Textures/LogoA.png");

	std::dynamic_pointer_cast<Hazel::OpenGLShader>(m_TShader)->Bind();
	std::dynamic_pointer_cast<Hazel::OpenGLShader>(m_TShader)->UploadUniformInt("u_Texture", 0);

}

void ExampleLayer::OnUpdate(Hazel::Timestep ts) {
	HZ_TRACE("Delta time : {0}s ({1}ms)", ts.GetSeconds(), ts.GetMillseconds());

	if (Hazel::Input::IsKeyPressed(HZ_KEY_LEFT))
		m_CameraPosition.x -= m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_RIGHT))
		m_CameraPosition.x += m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_UP))
		m_CameraPosition.y += m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_DOWN))
		m_CameraPosition.y -= m_CameraMoveSpeed * ts;

	if (Hazel::Input::IsKeyPressed(HZ_KEY_RIGHT_SHIFT))
		m_CameraRotation -= m_CameraRotationSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_LEFT_SHIFT))
		m_CameraRotation += m_CameraRotationSpeed * ts;


	if (Hazel::Input::IsKeyPressed(HZ_KEY_J))
		m_ModelPosition.x -= m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_L))
		m_ModelPosition.x += m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_I))
		m_ModelPosition.y += m_CameraMoveSpeed * ts;
	else if (Hazel::Input::IsKeyPressed(HZ_KEY_K))
		m_ModelPosition.y -= m_CameraMoveSpeed * ts;

	//�졢�̡����� alpha ֵ��ָ��ֵ��Χ��Ϊ[ 0.0f,1.0f ]
	//ָ����Ļ��ɫ.
	//glClearColor(0.2f, 0.1f, 0.3f, 1);
	Hazel::RenderCommand::SetClearColor({ 0.2f, 0.1f, 0.3f, 1 });
	//��֮ǰ��ɫȫ�����.�ָ�Ϊ��Ļ��ɫ
	//GL_COLOR_BUFFER_BIT ָ��Ϊ��ǰ������Ϊд��������ɫ����
	//glClear(GL_COLOR_BUFFER_BIT);
	Hazel::RenderCommand::Clear();

	m_Camera.SetPosition(m_CameraPosition);
	m_Camera.SetRotation(m_CameraRotation);

	glm::mat4 transform = glm::translate(glm::mat4(1.0f), m_ModelPosition);

	Hazel::Renderer::BeginScene(m_Camera);

	m_Texture->Bind();
	//Hazel::Renderer::Submit(m_Shader, m_VertexArray, transform);
	Hazel::Renderer::Submit(Hazel::RendererType::TRIANGLES, m_TShader, m_TVArray, transform);
	m_LogoTexture->Bind();
	Hazel::Renderer::Submit(Hazel::RendererType::TRIANGLES, m_TShader, m_TVArray, transform);
	//std::cout << m_VertexArray->GetIndexBuffer()->GetCount() << std::endl;
	Hazel::Renderer::EndScene();

}

void ExampleLayer::OnEvent(Hazel::Event& e)
{

}

void ExampleLayer::OnImGuiRender()
{
	ImGui::Begin("Setting");
	static glm::vec3 tmpcolortable = { 0.2f,0.3f,0.8f };
	ImGui::ColorEdit3("Square Color", glm::value_ptr(tmpcolortable));
	ImGui::End();
}